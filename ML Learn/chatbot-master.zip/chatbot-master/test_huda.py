from nltk.classify import MaxentClassifier
print 7